# -*- coding: utf-8 -*-

print("has cargado el modulo ADIOS")

def funcion_adios():
    print("hola, soy una funcion del modulo ADIOS")