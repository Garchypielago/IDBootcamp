# -*- coding: utf-8 -*-


print("has cargado el modulo HOLA")

def funcion_hola():
    print("hola, soy una funcion del modulo HOLA")