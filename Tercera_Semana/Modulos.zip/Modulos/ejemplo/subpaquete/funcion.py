# -*- coding: utf-8 -*-

def funcion_1():
    print("Soy una funcion del modulo funcion")