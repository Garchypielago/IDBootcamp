# -*- coding: utf-8 -*-
import numpy as np
print("estoy en el __init__ 2 del subpaquete")
__all__ = ["funcion"]
