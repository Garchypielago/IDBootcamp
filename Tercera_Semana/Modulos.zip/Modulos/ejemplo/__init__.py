# -*- coding: utf-8 -*-


print("estoy en el __init__")
__all__ = ["hola", "adios","subpaquete"] 
# el nombre de los modulos que quiero que cargue cuando utilice el '*'

x=10