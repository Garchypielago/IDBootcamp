print("estoy en un modulo")
import numpy as np

def exponente(x, e):
    """esta funcion eleva x a a la e"""
    return(x**e)
    
def suma(x):
    
    """esta funcion suma 1 a x"""
    return np.sum(x)

class MyClass:
    x=12

    
    
print("Adios")
print("Adios2")

    